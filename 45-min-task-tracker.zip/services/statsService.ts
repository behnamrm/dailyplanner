
import { DailyProgress, Task, StatRange } from '../types';

const getFormattedDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

export const calculateStats = (progress: DailyProgress, tasks: Task[], range: StatRange): { name: string; completions: number }[] => {
  const endDate = new Date();
  const startDate = new Date();

  switch (range) {
    case '1M':
      startDate.setMonth(startDate.getMonth() - 1);
      break;
    case '3M':
      startDate.setMonth(startDate.getMonth() - 3);
      break;
    case '6M':
      startDate.setMonth(startDate.getMonth() - 6);
      break;
    case '1Y':
      startDate.setFullYear(startDate.getFullYear() - 1);
      break;
  }
  
  const aggregatedData: { [taskId: string]: number } = {};
  tasks.forEach(task => aggregatedData[task.id] = 0);

  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    const dateStr = getFormattedDate(new Date(d));
    if (progress[dateStr]) {
      Object.entries(progress[dateStr]).forEach(([taskId, completions]) => {
        if (aggregatedData[taskId] !== undefined) {
          aggregatedData[taskId] += completions;
        }
      });
    }
  }

  return tasks.map(task => ({
    name: task.name,
    completions: aggregatedData[task.id] || 0,
  })).sort((a, b) => b.completions - a.completions);
};
