
import React, { useState, useMemo } from 'react';
import { ResponsiveContainer, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Bar } from 'recharts';
import { ValueType, NameType } from 'recharts/types/component/DefaultTooltipContent';
import { Task, DailyProgress, StatRange } from '../types';
import { calculateStats } from '../services/statsService';

interface StatsViewProps {
  tasks: Task[];
  progress: DailyProgress;
}

const StatRangeSelector: React.FC<{ selectedRange: StatRange, onSelect: (range: StatRange) => void }> = ({ selectedRange, onSelect }) => {
    const ranges: StatRange[] = ['1M', '3M', '6M', '1Y'];
    const buttonBaseClasses = "py-2 px-4 text-sm font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-light dark:focus:ring-offset-dark focus:ring-primary";
    const activeClasses = "bg-primary text-white shadow";
    const inactiveClasses = "bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600";

    return (
        <div className="flex justify-center space-x-2 p-2 bg-slate-200 dark:bg-slate-900 rounded-lg">
            {ranges.map(range => (
                <button
                    key={range}
                    onClick={() => onSelect(range)}
                    className={`${buttonBaseClasses} ${selectedRange === range ? activeClasses : inactiveClasses}`}
                >
                    {range === '1Y' ? '1 Year' : `${range.replace('M', '')} Months`}
                </button>
            ))}
        </div>
    );
};

const CustomTooltip = ({ active, payload, label }: { active?: boolean; payload?: { name: NameType; value: ValueType }[]; label?: NameType; }) => {
  if (active && payload && payload.length) {
    return (
      <div className="p-3 bg-slate-900 border border-slate-700 rounded-lg shadow-xl text-slate-100">
        <p className="font-bold text-primary mb-1">{`${label}`}</p>
        <p className="text-sm">{`${payload[0].name}: ${payload[0].value}`}</p>
      </div>
    );
  }

  return null;
};


const StatsView: React.FC<StatsViewProps> = ({ tasks, progress }) => {
  const [range, setRange] = useState<StatRange>('1M');

  const statData = useMemo(() => calculateStats(progress, tasks, range), [progress, tasks, range]);
  
  const totalCompletions = useMemo(() => statData.reduce((sum, item) => sum + item.completions, 0), [statData]);

  return (
    <div className="bg-white dark:bg-slate-800 p-4 sm:p-6 rounded-lg shadow-lg space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-2xl font-bold text-primary">Your Progress</h2>
          <p className="text-slate-500 dark:text-slate-400 mt-1">Total of {totalCompletions} 45-minute sessions completed.</p>
        </div>
        <StatRangeSelector selectedRange={range} onSelect={setRange} />
      </div>

      {statData.length > 0 && totalCompletions > 0 ? (
        <div className="w-full h-[400px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={statData}
              margin={{ top: 5, right: 20, left: -10, bottom: 20 }}
              layout="vertical"
              barCategoryGap="20%"
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(128, 128, 128, 0.2)" />
              <XAxis type="number" allowDecimals={false} stroke="rgb(100 116 139)" tick={{ fill: 'rgb(100 116 139)' }} />
              <YAxis type="category" dataKey="name" width={120} stroke="rgb(100 116 139)" tick={{ fill: 'rgb(156 163 175)'}} />
              <Tooltip
                cursor={{ fill: 'rgba(79, 70, 229, 0.1)' }}
                content={<CustomTooltip />}
              />
              <Legend wrapperStyle={{ paddingTop: '20px' }} />
              <Bar dataKey="completions" fill="#4f46e5" name="Completed Sessions" radius={[0, 4, 4, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-slate-500 dark:text-slate-400">No data available for this period. Keep tracking your tasks!</p>
        </div>
      )}
    </div>
  );
};

export default StatsView;
