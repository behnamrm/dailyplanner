
import React from 'react';
import { Task, DailyProgress } from '../types';
import TaskItem from './TaskItem';

interface DailyViewProps {
  tasks: Task[];
  progress: DailyProgress;
  onUpdateProgress: (taskId: string, count: number) => void;
}

const getFormattedDate = (date: Date): string => {
  return date.toISOString().split('T')[0];
};

const DailyView: React.FC<DailyViewProps> = ({ tasks, progress, onUpdateProgress }) => {
  const today = getFormattedDate(new Date());
  const todaysProgress = progress[today] || {};

  const todayFormatted = new Date().toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  return (
    <div className="space-y-6">
      <div className="p-4 bg-white dark:bg-slate-800 rounded-lg shadow">
        <h2 className="text-2xl font-bold text-primary">{todayFormatted}</h2>
        <p className="text-slate-500 dark:text-slate-400">Your tasks for today. Let's make it productive!</p>
      </div>

      {tasks.length > 0 ? (
        <div className="space-y-4">
          {tasks.map(task => (
            <TaskItem 
              key={task.id}
              task={task}
              completedCount={todaysProgress[task.id] || 0}
              onUpdate={(newCount) => onUpdateProgress(task.id, newCount)}
            />
          ))}
        </div>
      ) : (
        <div className="text-center py-10 px-4 bg-white dark:bg-slate-800 rounded-lg shadow">
          <p className="text-slate-500 dark:text-slate-400">No tasks yet. Add one to get started!</p>
        </div>
      )}
    </div>
  );
};

export default DailyView;
