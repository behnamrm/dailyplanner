
import React, { useRef } from 'react';
import { Task, DailyProgress } from '../types';

interface DataManagementProps {
  tasks: Task[];
  progress: DailyProgress;
  onImport: (data: { tasks: Task[]; progress: DailyProgress }) => void;
}

const DataManagement: React.FC<DataManagementProps> = ({ tasks, progress, onImport }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExport = () => {
    const data = {
      tasks,
      progress,
    };
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(
      JSON.stringify(data, null, 2)
    )}`;
    const link = document.createElement('a');
    link.href = jsonString;
    const date = new Date().toISOString().split('T')[0];
    link.download = `task-tracker-backup-${date}.json`;

    link.click();
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const text = e.target?.result;
        if (typeof text !== 'string') {
          throw new Error('File could not be read as text.');
        }
        const importedData = JSON.parse(text);

        // Basic validation to ensure the file structure is correct
        if (
          importedData &&
          Array.isArray(importedData.tasks) &&
          typeof importedData.progress === 'object' &&
          importedData.progress !== null
        ) {
          onImport(importedData);
        } else {
          alert('Error: Invalid backup file format.');
        }
      } catch (error) {
        console.error('Failed to parse backup file:', error);
        alert('Error: Could not import backup. The file may be corrupt or not a valid JSON.');
      }
    };
    reader.onerror = () => {
        alert('Error: Failed to read the file.');
    };
    reader.readAsText(file);
    // Reset the input value to allow importing the same file again if needed
    event.target.value = '';
  };

  const exportButtonClasses = "bg-primary text-white font-bold py-2 px-4 rounded-md hover:bg-indigo-700 transition-colors duration-200 disabled:bg-slate-400 disabled:cursor-not-allowed";
  const importButtonClasses = "bg-secondary text-white font-bold py-2 px-4 rounded-md hover:bg-emerald-600 transition-colors duration-200";

  return (
    <div className="p-4 sm:p-6 bg-white dark:bg-slate-800 rounded-lg shadow-lg">
      <h2 className="text-xl font-bold text-slate-700 dark:text-slate-200 mb-2">
        Backup &amp; Restore
      </h2>
      <p className="text-sm text-slate-500 dark:text-slate-400 mb-4">
        Save your tasks and progress to a file, or restore from a backup.
      </p>
      <div className="flex flex-col sm:flex-row gap-4">
        <button
          onClick={handleExport}
          className={exportButtonClasses}
          disabled={tasks.length === 0 && Object.keys(progress).length === 0}
          aria-label="Export all tasks and progress to a file"
        >
          Export Backup
        </button>
        <button 
          onClick={handleImportClick} 
          className={importButtonClasses}
          aria-label="Import tasks and progress from a backup file"
        >
          Import Backup
        </button>
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept=".json,application/json"
          className="hidden"
          aria-hidden="true"
        />
      </div>
    </div>
  );
};

export default DataManagement;
