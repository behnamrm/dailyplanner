
import React from 'react';
import { View } from '../types';

interface HeaderProps {
  currentView: View;
  setView: (view: View) => void;
}

const Header: React.FC<HeaderProps> = ({ currentView, setView }) => {
  const buttonBaseClasses = "py-2 px-6 rounded-md font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-light dark:focus:ring-offset-dark focus:ring-primary";
  const activeClasses = "bg-primary text-white shadow-lg";
  const inactiveClasses = "bg-white dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-600";

  return (
    <nav className="bg-slate-200 dark:bg-slate-800 p-2 rounded-lg flex justify-center space-x-2 md:space-x-4">
      <button 
        onClick={() => setView('daily')}
        className={`${buttonBaseClasses} ${currentView === 'daily' ? activeClasses : inactiveClasses}`}
      >
        Daily
      </button>
      <button 
        onClick={() => setView('stats')}
        className={`${buttonBaseClasses} ${currentView === 'stats' ? activeClasses : inactiveClasses}`}
      >
        Statistics
      </button>
    </nav>
  );
};

export default Header;
